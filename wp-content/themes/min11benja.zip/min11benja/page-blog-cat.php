<?php
/*
Template Name: Blog Cat Page
*/
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package min11benja
 */

get_header();
?>

 <!-- hero  -->
            <div class="hero-01">
                <div class="hero-border">
                    <div class="top"></div>
                    <div class="bottom"></div>
                    <div class="left"></div>
                    <div class="right">
                        <div class="v-area">
                            <div class="v-middle  show-span">
                                <div class="p5" id="label-menu">
                                    
                                    <span>S</span>
                                    <span>T</span>
                                    <span>O</span>
                                    <span>R</span>
                                    <span>I</span>
                                    <span>E</span>
                                    <span>S</span>
                                    <span></span>
                                    <span>M</span>
                                    <span>A</span>
                                    <span>T</span>
                                    <span>T</span>
                                    <span>E</span>
                                    <span>R</span>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="my-thumb">
                    <div class="thumb-top"><a href="<?php bloginfo('template_directory');?>/assets/theme/img/pic/min11benja-bw.png" class="image-popup" title="min11benja"><img src="<?php bloginfo('template_directory');?>/assets/theme/img/min11benja-bw.png" class="img-thumbnail no-radius"  alt=""></a></div>
                </div>

                <div class="content-hero">
                    <div class="v-content">
                        <h4 class="font-normal">Hola extrañ@, este es mi blog personal</h4>
                        <h1 class="myname">min11benja</h1>
                        <h2>Donde comparto mis experiencias, las personas que conozco, los libros que estoy leyendo y lo que estoy aprendiendo<small class="text-yellow"><br>&rarr; Espero y te unas a la conversación</small></h2>
                        <p><a href="#" class="btn btnc1"><span>Suscribete</span></a></p>
                    </div>
                </div>
            </div>
            <!-- hero  -->
        </header>
        <!-- end Header -->
        
        <!-- Content body -->
        <div class="content-body ">


            <div class="section-padd br-t " id="blog-cat">
                <div class="container-body clearfix tab_container">

                    <!--Cat Blog Tabs-->

                    <input id="tab1" type="radio" name="tabs" checked>
                    <label for="tab1"><i class="fa fa-bar-chart-o "></i><br><span></span></label>

                    <input id="tab2" type="radio" name="tabs">
                    <label for="tab2"><i class="fa fa-mortar-board "></i><span></span></label>

                    <input id="tab3" type="radio" name="tabs">
                    <label for="tab3"><i class="fa fa-newspaper-o"></i><span></span></label>

                    <input id="tab4" type="radio" name="tabs">
                    <label for="tab4"><i class="fa fa-calendar"></i><span></span></label>

                    <input id="tab5" type="radio" name="tabs">
                    <label for="tab5"><i class="fa fa-users"></i><span></span></label>

                    <section id="content1" class="tab-content">


                        <div class="blog-card">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li>Total Articulos:#482</li>
                                    <li>Total Suscriptores:#10,101</li>
                                    <li>Total Vistas: #1,000,000</li>
                                    <li>Total Comentarios:#744</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">LOS TOP 3 BLOGS MÁS VISTOS</h1>
                                <h2>Los temas más populares y vistos del 2018</h2>

                            </div>
                        </div>

                        <div class="blog-card alt">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li class="author"><a href="#">Benjamin</a></li>
                                    <li class="date">Aug. 24, 2015</li>
                                    <li class="tags">
                                        <ul>
                                            <li><a href="#">Learn</a></li>
                                            <li><a href="#">Code</a></li>
                                            <li><a href="#">HTML</a></li>
                                            <li><a href="#">CSS</a></li>
                                        </ul>
                                    </li>
                                    <li>Vistas: #100,000</li>
                                    <li>Comentarios:#44</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">Learning to Code</h1>
                                <h2>Opening a door to the future</h2>
                                <p class="text-black"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium, quam nobis! Neque ad aliquam facilis numquam. Veritatis, sit.</p>
                                <p class="read-more">
                                    <a href="#" class="post-link">Leer más</a>
                                </p>
                            </div>
                        </div>

                        <div class="blog-card alt">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-2.jpg)"></div>
                                <ul class="details">
                                    <li class="author"><a href="#">Benjamin</a></li>
                                    <li class="date">July. 15, 2015</li>
                                    <li class="tags">
                                        <ul>
                                            <li><a href="#">Learn</a></li>
                                            <li><a href="#">Code</a></li>
                                            <li><a href="#">JavaScript</a></li>
                                        </ul>
                                    </li>
                                    <li>Vistas: #60,000</li>
                                    <li>Comentarios:#21</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">Mastering the Language</h1>
                                <h2>Java is not the same as JavaScript</h2>
                                <p class="text-black">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium, quam nobis! Neque ad aliquam facilis numquam. Veritatis, sit.</p>
                                <p class="read-more">
                                    <a href="#" class="post-link">Leer más</a>
                                </p>
                            </div>
                        </div>

                        <div class="blog-card alt">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li class="author"><a href="#">Benjamin</a></li>
                                    <li class="date">Aug. 24, 2015</li>
                                    <li class="tags">
                                        <ul>
                                            <li><a href="#">Learn</a></li>
                                            <li><a href="#">Code</a></li>
                                            <li><a href="#">HTML</a></li>
                                            <li><a href="#">CSS</a></li>
                                        </ul>
                                    </li>
                                    <li>Vistas: #100,000</li>
                                    <li>Comentarios:#44</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">Learning to Code</h1>
                                <h2>Opening a door to the future</h2>
                                <p class="text-black"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium, quam nobis! Neque ad aliquam facilis numquam. Veritatis, sit.</p>
                                <p class="read-more">
                                    <a href="#" class="post-link">Leer más</a>
                                </p>
                            </div>
                        </div>
                    </section>

                    <section id="content2" class="tab-content">
                        <div class="blog-card">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li>Total Articulos:#482</li>
                                    <li>Total Suscriptores:#10,101</li>
                                    <li>Total Vistas: #1,000,000</li>
                                    <li>Total Comentarios:#744</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">LO QUE ESTOY APRENDIENDO</h1>
                                <h2>Aprende conmigo, te dejo mis tips recursos y obstaculos</h2>

                            </div>
                        </div>

                        <div class="blog-card alt">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li class="author"><a href="#">Benjamin</a></li>
                                    <li class="date">Aug. 24, 2015</li>
                                    <li class="tags">
                                        <ul>
                                            <li><a href="#">Learn</a></li>
                                            <li><a href="#">Code</a></li>
                                            <li><a href="#">HTML</a></li>
                                            <li><a href="#">CSS</a></li>
                                        </ul>
                                    </li>
                                    <li>Vistas: #100,000</li>
                                    <li>Comentarios:#44</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">Learning to Code</h1>
                                <h2>Opening a door to the future</h2>
                                <p class="text-black"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium, quam nobis! Neque ad aliquam facilis numquam. Veritatis, sit.</p>
                                <p class="read-more">
                                    <a href="#" class="post-link">Leer más</a>
                                </p>
                            </div>
                        </div>

                        <div class="blog-card alt">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-2.jpg)"></div>
                                <ul class="details">
                                    <li class="author"><a href="#">Benjamin</a></li>
                                    <li class="date">July. 15, 2015</li>
                                    <li class="tags">
                                        <ul>
                                            <li><a href="#">Learn</a></li>
                                            <li><a href="#">Code</a></li>
                                            <li><a href="#">JavaScript</a></li>
                                        </ul>
                                    </li>
                                    <li>Vistas: #60,000</li>
                                    <li>Comentarios:#21</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">Mastering the Language</h1>
                                <h2>Java is not the same as JavaScript</h2>
                                <p class="text-black">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium, quam nobis! Neque ad aliquam facilis numquam. Veritatis, sit.</p>
                                <p class="read-more">
                                    <a href="#" class="post-link">Leer más</a>
                                </p>
                            </div>
                        </div>

                        <div class="blog-card alt">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li class="author"><a href="#">Benjamin</a></li>
                                    <li class="date">Aug. 24, 2015</li>
                                    <li class="tags">
                                        <ul>
                                            <li><a href="#">Learn</a></li>
                                            <li><a href="#">Code</a></li>
                                            <li><a href="#">HTML</a></li>
                                            <li><a href="#">CSS</a></li>
                                        </ul>
                                    </li>
                                    <li>Vistas: #100,000</li>
                                    <li>Comentarios:#44</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">Learning to Code</h1>
                                <h2>Opening a door to the future</h2>
                                <p class="text-black"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium, quam nobis! Neque ad aliquam facilis numquam. Veritatis, sit.</p>
                                <p class="read-more">
                                    <a href="#" class="post-link">Leer más</a>
                                </p>
                            </div>
                        </div>
                    </section>
                    <!--Books and Movies-->
                    <section id="content3" class="tab-content">

                        <div class="blog-card">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li>Total Articulos:#482</li>
                                    <li>Total Suscriptores:#10,101</li>
                                    <li>Total Vistas: #1,000,000</li>
                                    <li>Total Comentarios:#744</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">MIS 5 CENTAVOS EN TODO</h1>
                                <h2>Te comparto mi opinion en libros, peliculas, herramientas y servicio que uso</h2>

                            </div>
                        </div>

                        <div class="blog-card alt">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-2.jpg)"></div>
                                <ul class="details">
                                    <li class="author"><a href="#">Benjamin</a></li>
                                    <li class="date">July. 15, 2015</li>
                                    <li class="tags">
                                        <ul>
                                            <li><a href="#">Learn</a></li>
                                            <li><a href="#">Code</a></li>
                                            <li><a href="#">JavaScript</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">Mastering the Language</h1>
                                <h2>Java is not the same as JavaScript</h2>
                                <p class="text-black">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium, quam nobis! Neque ad aliquam facilis numquam. Veritatis, sit.</p>
                                <p class="read-more">
                                    <a href="#" class="post-link">Leer más</a>
                                </p>
                            </div>
                        </div>
                    </section>
                    <!--Experiences-->
                    <section id="content4" class="tab-content">
                        <div class="blog-card">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li>Total Articulos:#482</li>
                                    <li>Total Suscriptores:#10,101</li>
                                    <li>Total Vistas: #1,000,000</li>
                                    <li>Total Comentarios:#744</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">COSAS QUE VALEN LA PENA CONTAR</h1>
                                <h2>Cosas que me han pasado, y como reaccione a estos sucesos</h2>

                            </div>
                        </div>
                        <div class="blog-card alt">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li class="author"><a href="#">Benjamin</a></li>
                                    <li class="date">Aug. 24, 2015</li>
                                    <li class="tags">
                                        <ul>
                                            <li><a href="#">Learn</a></li>
                                            <li><a href="#">Code</a></li>
                                            <li><a href="#">HTML</a></li>
                                            <li><a href="#">CSS</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">Learning to Code</h1>
                                <h2>Opening a door to the future</h2>
                                <p class="text-black"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium, quam nobis! Neque ad aliquam facilis numquam. Veritatis, sit.</p>
                                <p class="read-more">
                                    <a href="#" class="post-link">Leer más</a>
                                </p>
                            </div>
                        </div>
                    </section>
                    <!--people i meet-->
                    <section id="content5" class="tab-content">
                        <div class="blog-card">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-1.jpg)"></div>
                                <ul class="details">
                                    <li>Total Articulos:#482</li>
                                    <li>Total Suscriptores:#10,101</li>
                                    <li>Total Vistas: #1,000,000</li>
                                    <li>Total Comentarios:#744</li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">PERSONAS INTERESANTES</h1>
                                <h2>People dont cross our path by accident, they are either a blessing or a lesson</h2>

                            </div>
                        </div>
                        <div class="blog-card alt">
                            <div class="meta">
                                <div class="photo" style="background-image: url(https://storage.googleapis.com/chydlx/codepen/blog-cards/image-2.jpg)"></div>
                                <ul class="details">
                                    <li class="author"><a href="#">Benjamin</a></li>
                                    <li class="date">July. 15, 2015</li>
                                    <li class="tags">
                                        <ul>
                                            <li><a href="#">Learn</a></li>
                                            <li><a href="#">Code</a></li>
                                            <li><a href="#">JavaScript</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <div class="description">
                                <h1 class="text-black">Mastering the Language</h1>
                                <h2>Java is not the same as JavaScript</h2>
                                <p class="text-black">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad eum dolorum architecto obcaecati enim dicta praesentium, quam nobis! Neque ad aliquam facilis numquam. Veritatis, sit.</p>
                                <p class="read-more">
                                    <a href="#" class="post-link">Leer más</a>
                                </p>
                            </div>
                        </div>
                    </section>
                    <!--/ Cat Blog Tabs-->
                </div>
            </div>


            <!--Subscribe Form -->
            <section class="widget widget_blog_subscription">
                <form action="#" method="post" accept-charset="utf-8" id="subscribe-blog">
                    <p>Suscribete a nuestro Boletin semanal<br>¡Para obténer contenido exclusivo y enterarte de nuevos articulos antes que nadie!</p>
                    <p>
                        <input type="text" name="email" style="width: 95%;" placeholder="Deja tu correo" value="" id="subscribe-field">
                    </p>
                    <p>
                        <input type="submit" value="¡Suscribeme!">
                    </p>
                </form>
            </section>
            <!-- End Subscribe Form -->

        </div>
        <!-- end Content body -->


<?php get_footer();?>